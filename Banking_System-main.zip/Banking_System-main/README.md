## Getting Started

This is Login Page
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/cfe0c3a5-deac-4e2e-8c13-971b5478c758)

This is SignUp page 1
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/6496dc6d-7185-47ce-a52f-24a028867742)

This is SignUp page 2
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/f7e17734-aa5b-4b30-9c09-d8ca06c27401)


This is SignUp page 3
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/f4c76e3c-931f-4159-a118-ad5db60c7cab)

Enter username and password and login 
Main page
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/56a89a97-0e62-49a1-91a8-10db7e098ca6)

This is Account Details page  *You will be required to enter your password before viewing your account details.
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/0c0f523e-943a-47a9-8537-2db3d8ac8d2e)

This is ATM Card (click on View ATM Card)
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/7a426fc2-f75c-45bf-ad11-8e8d212dbf76)

This is Pin Change Page 
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/2faa08af-cec3-405e-bb4f-92d5e67e250d)

This is Quick Pay page (using this we can send money)
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/4968ef3f-9016-4740-9faa-fe1728087911)

This is History Page * we can see tranjaction history
![image](https://github.com/ajayvijay9929/Banking_System/assets/120326151/1bc1fec1-7736-468a-95a4-1963ce10642f)
E:\OneDrive\Java Project\Banking_System




Welcome to the VS Code Java world. Here is a guideline to help you get started to write Java code in Visual Studio Code.

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.

> If you want to customize the folder structure, open `.vscode/settings.json` and update the related settings there.

## Dependency Management

The `JAVA PROJECTS` view allows you to manage your dependencies. More details can be found [here](https://github.com/microsoft/vscode-java-dependency#manage-dependencies).
